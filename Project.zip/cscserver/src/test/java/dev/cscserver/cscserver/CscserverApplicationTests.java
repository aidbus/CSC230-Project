package dev.cscserver.cscserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CscserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
