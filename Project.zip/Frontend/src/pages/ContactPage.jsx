import React from "react";

function ContactPage() {
  return (
    <div>
      <h2>Contact Us</h2>
      <p>Get in touch with us via email at criminology.journal@example.com.</p>
    </div>
  );
}

export default ContactPage;